from django.db import models

# Create your models here.

from django.db import models


class proffesors(models.Model):
    prof_id = models.IntegerField()
    name = models.TextField()
    age = models.IntegerField()


