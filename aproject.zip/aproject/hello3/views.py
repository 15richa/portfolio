from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse



def hello3(response):
    return HttpResponse("<h1> Hello3 page </h1>")

