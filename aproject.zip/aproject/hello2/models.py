from django.db import models

# Create your models here.

from django.db import models


class stu_fee(models.Model):
    stu_id = models.IntegerField()
    status = models.TextField()
    fee = models.IntegerField()
