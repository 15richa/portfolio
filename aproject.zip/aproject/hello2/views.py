from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse



def hello2(response):
    return HttpResponse("<h1> Hello2 page </h1>")

